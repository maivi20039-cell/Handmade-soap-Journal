# 🧼 The Soap Maker's Studio

A complete digital business journal for artisan soap makers.
Built with React. Deploy-ready for Vercel.

---

## 📁 What's in this folder

```
soap-journal-deploy/
├── public/
│   └── index.html        ← The webpage shell
├── src/
│   ├── index.js          ← App entry point
│   └── App.jsx           ← Your full app (all 7 sections)
├── package.json          ← Project settings
├── vercel.json           ← Vercel deploy settings
└── README.md             ← This file
```

---

## 🚀 How to deploy to Vercel (step by step)

### Step 1 — Upload to GitHub

1. Go to github.com and sign in (or create a free account)
2. Click the **+** button → **New repository**
3. Name it: `soap-journal`
4. Click **Create repository**
5. On the next screen, click **uploading an existing file**
6. Drag and drop ALL files from this folder into GitHub
   ⚠️ Make sure to upload the `src` and `public` folders too
7. Click **Commit changes**

### Step 2 — Deploy on Vercel

1. Go to vercel.com and sign in
2. Click **Add New Project**
3. Click **Import** next to your `soap-journal` GitHub repo
4. Vercel will auto-detect the settings — just click **Deploy**
5. Wait ~2 minutes ⏳
6. Vercel gives you a live link like: `https://soap-journal.vercel.app`

That's it! Your app is live. 🎉

### Step 3 — Sell it on Gumroad

1. Go to gumroad.com → Create account
2. Click **New Product** → **Digital Product**
3. Name: "The Soap Maker's Studio — Digital Journal"
4. Price: $12–$18 recommended
5. In the description, paste your Vercel link
6. Add screenshots of the app
7. Publish!

---

## ✨ Features included

- ✦ Soap Recipe Creator
- ◈ Batch Log
- ◉ Cure Rack Tracker with live countdown
- ▣ Ingredient Inventory with reorder alerts
- ◇ Soap Testing & ratings
- ◎ Cost Per Batch Calculator with profit margin
- ◆ Market & Sales Tracker
- 🌐 English / Spanish toggle
- ✏️ Custom business name & tagline
- ↓ Export to CSV + Print to PDF
- 💡 Help tooltips on every section
- 💾 Auto-saves to browser (no account needed)

---

## 💬 Need help?

If something doesn't work, the most common fix is:
- Make sure you uploaded the `src/` folder AND `public/` folder to GitHub
- Check that `package.json` is in the ROOT of the repository (not inside a subfolder)
